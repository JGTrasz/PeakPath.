package com.example.final_hike

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
